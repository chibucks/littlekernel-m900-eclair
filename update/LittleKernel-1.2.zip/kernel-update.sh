#!/system/bin/sh
#SDX sdx-developers.com scripted
flash_image boot /system/LittleKernel
